plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.qxpro.app"; compileSdk = 34
    defaultConfig { applicationId = "com.qxpro.app"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
}
